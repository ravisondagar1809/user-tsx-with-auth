import React from 'react'

function AuthHeader() {
  return (
    <div>AuthHeader</div>
  )
}

export default AuthHeader