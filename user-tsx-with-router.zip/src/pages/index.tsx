import React, { useEffect } from "react";
import { Route, Switch, Redirect, useLocation } from "react-router";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import { ApiGet } from "../helper/API/ApiData";
import AuthStorage from "../helper/AuthStorage";
import Layout from "../layouts/Layout";
import { changeLoginState } from "../redux/actions/loginAction";
import homepage from "./homepage/Homepage";
import LoginLayout from "../layouts/LoginLayout";
import Login from "../modal/Login";

const Index = () => {
  const pathname = ["/login"]
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  useEffect(() => {
    if (AuthStorage.isUserAuthenticated()) {
      ApiGet("user/validate")
        .then((res) => {
          dispatch(changeLoginState(true));
        })
        .catch((error) => {
          AuthStorage.deauthenticateUser();
          history.push("/");
        });
    }
    else {
      if (!pathname.includes(location.pathname)) {
        history.push("/");
      }
    }
  }, []);

  return (
    <>

      <Switch>
        <Route
          exact
          path={[
            "/",
            "/homepage"
          ]}
        >
          <Layout>
            <Switch>
              <RouteWrapper
                exact={true}
                path="/"
                component={homepage}

                isPrivateRoute={false}
              />

              <RouteWrapper
                exact={true}
                path="/homepage"
                component={homepage}

                isPrivateRoute={false}
              />

            </Switch>
          </Layout>
        </Route>
        <Route
          exact
          path={[
            "/login"
          ]}
        >
          <LoginLayout>
            <Switch>
              <RouteWrapper
                exact={false}
                path="/login"
                component={Login}

                isPrivateRoute={false}
              />
             
             
            </Switch>
          </LoginLayout>
        </Route>
     
        <Redirect from="**" to="/error" />
      </Switch>
    </>
  );
};

export default Index;

interface RouteWrapperProps {
  component: any;
  exact: boolean;
  path: string;
  isPrivateRoute: boolean;
}

function RouteWrapper({
  component: Component,
  isPrivateRoute,
  ...rest
}: RouteWrapperProps) {
  const history = useHistory();
  const isAuthenticated: boolean = isPrivateRoute
    ? AuthStorage.isUserAuthenticated()
    : true;
  return (
    <>
      {isAuthenticated ? (
        <Route {...rest} render={(props) => <Component {...props} />} />
      ) : (
        history.push("/")
      )}
    </>
  );
}
