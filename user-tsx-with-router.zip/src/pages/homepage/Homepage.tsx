
const Homepage = () => {

    return (
        <>
            <h1>Home Page</h1>
        </>
    )
}

export default Homepage
