const STORAGEKEY = {
    token: 'token',
    userData: 'userData',
    userId: 'userId',
    layoutData: 'layoutData',
    roles: 'roles',
    email: 'email',
    lang: 'i18nextLng',
    donationData: 'donationData'
};

export default STORAGEKEY
